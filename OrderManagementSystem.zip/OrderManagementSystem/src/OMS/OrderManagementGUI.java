package OMS;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Comparator;

public class OrderManagementGUI extends JFrame {
    private JTextField usernameField;
    private JTextField orderIDField;
    private JTextField orderDetailsField;
    private JTextArea orderHistoryArea;
    private JButton loginButton;
    private JButton logoutButton;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton viewOrdersButton;
    private JComboBox<String> sortOptions;

    private OrderManager orderManager;

    public OrderManagementGUI() {
        orderManager = new OrderManager();

        setTitle("Order Management System");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        usernameField = new JTextField(15);
        orderIDField = new JTextField(10);
        orderDetailsField = new JTextField(15);
        orderHistoryArea = new JTextArea(20, 40);
        orderHistoryArea.setEditable(false);

        loginButton = new JButton("Login");
        logoutButton = new JButton("Logout");
        addButton = new JButton("Add Order");
        editButton = new JButton("Edit Order");
        deleteButton = new JButton("Delete Order");
        viewOrdersButton = new JButton("View Orders");

        sortOptions = new JComboBox<>(new String[]{"Order ID", "Order Details"});

        add(new JLabel("Username:"));
        add(usernameField);
        add(loginButton);
        add(logoutButton);
        add(new JLabel("Order ID:"));
        add(orderIDField);
        add(new JLabel("Order Details:"));
        add(orderDetailsField);
        add(addButton);
        add(editButton);
        add(deleteButton);
        add(viewOrdersButton);
        add(new JLabel("Sort By:"));
        add(sortOptions);
        add(new JScrollPane(orderHistoryArea));

        loginButton.addActionListener(new LoginButtonListener());
        logoutButton.addActionListener(e -> logoutUser());
        addButton.addActionListener(e -> addOrder());
        editButton.addActionListener(e -> editOrder());
        deleteButton.addActionListener(e -> deleteOrder());
        viewOrdersButton.addActionListener(e -> viewOrders());

        updateButtons();
        setVisible(true);
    }

    private void updateButtons() {
        boolean loggedIn = orderManager.isLoggedIn();
        logoutButton.setEnabled(loggedIn);
        addButton.setEnabled(loggedIn);
        editButton.setEnabled(loggedIn);
        deleteButton.setEnabled(loggedIn);
        viewOrdersButton.setEnabled(loggedIn);
    }

    private void addOrder() {
        String orderID = orderIDField.getText();
        String orderDetails = orderDetailsField.getText();
        if (!orderID.isEmpty() && !orderDetails.isEmpty()) {
            orderManager.getCurrentUser().addOrder(orderID, orderDetails);
            orderHistoryArea.append("Order added: " + orderID + "\n");
            clearFields();
        }
    }

    private void editOrder() {
        String orderID = orderIDField.getText();
        String orderDetails = orderDetailsField.getText();
        if (!orderID.isEmpty() && !orderDetails.isEmpty()) {
            orderManager.getCurrentUser().editOrder(orderID, orderDetails);
            orderHistoryArea.append("Order edited: " + orderID + "\n");
            clearFields();
        }
    }

    private void deleteOrder() {
        String orderID = orderIDField.getText();
        if (!orderID.isEmpty()) {
            orderManager.getCurrentUser().deleteOrder(orderID);
            orderHistoryArea.append("Order deleted: " + orderID + "\n");
            clearFields();
        }
    }

    private void viewOrders() {
        ArrayList<Order> orders = new ArrayList<>(orderManager.getCurrentUser().getOrders().values());
        if (sortOptions.getSelectedItem().equals("Order ID")) {
            orders.sort(Comparator.comparing(Order::getOrderID));
        } else {
            orders.sort(Comparator.comparing(Order::getOrderDetails));
        }
        orderHistoryArea.setText("Order History:\n");
        for (Order order : orders) {
            orderHistoryArea.append(order + "\n");
        }
    }

    private void clearFields() {
        orderIDField.setText("");
        orderDetailsField.setText("");
    }

    private void logoutUser() {
        orderManager.logoutUser();
        orderHistoryArea.setText("Logged out.\n");
        updateButtons();
    }

    private class LoginButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText();
            if (!username.isEmpty()) {
                orderManager.loginUser(username);
                orderHistoryArea.setText("Logged in as: " + username + "\n");
                updateButtons();
            }
        }
    }

//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(OrderManagementGUI::new);
//    }
}
