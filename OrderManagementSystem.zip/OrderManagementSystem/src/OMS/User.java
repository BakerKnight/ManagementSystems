package OMS;
import java.util.HashMap;

public class User {
    private String username;
    private HashMap<String, Order> orders;

    public User(String username) {
        this.username = username;
        this.orders = new HashMap<>();
    }

    public String getUsername() {
        return username;
    }

    public HashMap<String, Order> getOrders() {
        return orders;
    }

    public void addOrder(String orderID, String orderDetails) {
        orders.put(orderID, new Order(orderID, orderDetails));
    }

    public void editOrder(String orderID, String newDetails) {
        if (orders.containsKey(orderID)) {
            orders.get(orderID).setOrderDetails(newDetails);
        }
    }

    public void deleteOrder(String orderID) {
        orders.remove(orderID);
    }
}

