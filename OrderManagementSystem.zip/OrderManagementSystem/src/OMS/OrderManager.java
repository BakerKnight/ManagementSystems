package OMS;
import java.util.HashMap;

public class OrderManager {
    private HashMap<String, User> users;
    private User currentUser;

    public OrderManager() {
        users = new HashMap<>();
        currentUser = null;
    }

    public boolean loginUser(String username) {
        if (!users.containsKey(username)) {
            users.put(username, new User(username));
        }
        currentUser = users.get(username);
        return true;
    }

    public void logoutUser() {
        currentUser = null;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }
}

