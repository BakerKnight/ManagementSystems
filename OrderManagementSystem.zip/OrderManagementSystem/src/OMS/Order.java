package OMS;

public class Order {
    private String orderID;
    private String orderDetails;

    public Order(String orderID, String orderDetails) {
        this.orderID = orderID;
        this.orderDetails = orderDetails;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(String orderDetails) {
        this.orderDetails = orderDetails;
    }

    @Override
    public String toString() {
        return "Order ID: " + orderID + " | Details: " + orderDetails;
    }
}
